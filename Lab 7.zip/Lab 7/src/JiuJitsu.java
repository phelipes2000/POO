public interface JiuJitsu extends ArteMarcial {

    public int armLock();
    public int guilhotina();

}