public interface Fogo extends Armamento{
    public int coronhada();
    public int atirar();
}
