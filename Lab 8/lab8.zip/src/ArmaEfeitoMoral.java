public interface ArmaEfeitoMoral {
	
	public Golpe explodir();

}