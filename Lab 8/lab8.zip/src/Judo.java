
public interface Judo extends ArteMarcial {
	
	public int ipponSeioiNague();
	public int haraiGoshi();

}
