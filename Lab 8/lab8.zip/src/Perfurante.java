public interface Perfurante {
    public double furar();
    public double furarRasgar();
}
