
public interface ArteMarcial {

}
