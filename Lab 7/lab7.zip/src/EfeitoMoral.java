public interface EfeitoMoral {
    public int cegar();
    public int atordoar();
}
