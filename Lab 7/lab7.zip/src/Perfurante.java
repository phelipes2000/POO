public interface Perfurante {
    public int furar();
    public int furarRasgar();
}
