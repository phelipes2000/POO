public interface Armamento {
    
}
