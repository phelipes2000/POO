
public interface Karate extends ArteMarcial {
	
	public int magueri();
	public int guedanBarai();

}
