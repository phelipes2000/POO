public interface ArmaFogo {
	
	public Golpe atirar();

}