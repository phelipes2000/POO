public class Golpe {

	String nomeGolpe; 
	double poderOfensivo;
	
	Golpe(String nomeGolpe, double poderOfensivo){
		this.nomeGolpe = nomeGolpe;
		this.poderOfensivo = poderOfensivo;
	}

}