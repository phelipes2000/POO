public class Arquivo {

}
